"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Zap, Mail, ArrowLeft, CheckCircle } from "lucide-react"
import Link from "next/link"

export default function ForgotPasswordPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [isEmailSent, setIsEmailSent] = useState(false)

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    // Simulate password reset
    setTimeout(() => {
      setIsLoading(false)
      setIsEmailSent(true)
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Logo */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center space-x-2">
            <div className="relative">
              <Zap className="h-10 w-10 text-green-400" />
              <div className="absolute inset-0 h-10 w-10 text-green-400 animate-pulse opacity-50" />
            </div>
            <span className="text-3xl font-bold text-white">Lumen</span>
          </div>
        </div>

        {/* Reset Password Card */}
        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-center text-white">
              {isEmailSent ? "Check your email" : "Reset password"}
            </CardTitle>
            <p className="text-center text-slate-400">
              {isEmailSent
                ? "We've sent a password reset link to your email address"
                : "Enter your email address and we'll send you a reset link"}
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            {isEmailSent ? (
              <div className="text-center space-y-4">
                <div className="mx-auto w-16 h-16 bg-green-400/20 rounded-full flex items-center justify-center">
                  <CheckCircle className="h-8 w-8 text-green-400" />
                </div>
                <div className="space-y-2">
                  <p className="text-white font-medium">Email sent successfully!</p>
                  <p className="text-sm text-slate-400">
                    Didn't receive the email? Check your spam folder or{" "}
                    <button onClick={() => setIsEmailSent(false)} className="text-green-400 hover:text-green-300">
                      try again
                    </button>
                  </p>
                </div>
                <Link href="/auth/login">
                  <Button className="w-full bg-green-400 hover:bg-green-500 text-slate-900 font-semibold">
                    Back to Sign In
                  </Button>
                </Link>
              </div>
            ) : (
              <form onSubmit={handleResetPassword} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-slate-300">
                    Email address
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email address"
                      className="pl-10 bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                      required
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-green-400 hover:bg-green-500 text-slate-900 font-semibold"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-slate-900 border-t-transparent rounded-full animate-spin" />
                      <span>Sending...</span>
                    </div>
                  ) : (
                    "Send Reset Link"
                  )}
                </Button>
              </form>
            )}

            {!isEmailSent && (
              <Link href="/auth/login">
                <Button variant="ghost" className="w-full text-slate-300 hover:text-white">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Sign In
                </Button>
              </Link>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
