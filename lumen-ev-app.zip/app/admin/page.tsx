"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import {
  BarChart3,
  Zap,
  MapPin,
  Plus,
  Edit,
  Trash2,
  Calendar,
  DollarSign,
  TrendingUp,
  Activity,
  Settings,
  Bell,
  User,
  LogOut,
  Users,
  AlertTriangle,
  CheckCircle,
  Clock,
  Shield,
  Eye,
  Download,
  Filter,
  Search,
  MoreHorizontal,
  Layers,
  Target,
  Leaf,
  PieChart,
  TrendingDown,
} from "lucide-react"

export default function AdminPanel() {
  const [isAddStationOpen, setIsAddStationOpen] = useState(false)
  const [selectedTimeRange, setSelectedTimeRange] = useState("7d")
  const [realTimeData, setRealTimeData] = useState({
    activeUsers: 1247,
    totalBookings: 2847,
    revenue: 18492,
    carbonSaved: 125847,
  })

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setRealTimeData(prev => ({
        activeUsers: prev.activeUsers + Math.floor(Math.random() * 10) - 5,
        totalBookings: prev.totalBookings + Math.floor(Math.random() * 3),
        revenue: prev.revenue + Math.floor(Math.random() * 100),
        carbonSaved: prev.carbonSaved + Math.floor(Math.random() * 50),
      }))
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  const stats = [
    {
      title: "Active Users",
      value: realTimeData.activeUsers.toLocaleString(),
      change: "+12.5%",
      icon: <Users className="h-6 w-6 text-blue-400" />,
      trend: "up",
    },
    {
      title: "Total Bookings",
      value: realTimeData.totalBookings.toLocaleString(),
      change: "+8.3%",
      icon: <Calendar className="h-6 w-6 text-green-400" />,
      trend: "up",
    },
    {
      title: "Revenue",
      value: `$${realTimeData.revenue.toLocaleString()}`,
      change: "+15.7%",
      icon: <DollarSign className="h-6 w-6 text-yellow-400" />,
      trend: "up",
    },
    {
      title: "CO₂ Saved",
      value: `${realTimeData.carbonSaved.toLocaleString()} kg`,
      change: "+22.1%",
      icon: <Leaf className="h-6 w-6 text-green-400" />,
      trend: "up",
    },
  ]

  const stations = [
    {
      id: 1,
      name: "Tesla Supercharger - Downtown Plaza",
      location: "123 Main St, New York, NY",
      status: "Active",
      connectors: 8,
      utilization: 85,
      revenue: "$2,340",
      lastMaintenance: "2024-01-10",
      qrScans: 156,
      avgRating: 4.8,
      totalSessions: 1247,
      carbonOffset: 2847,
    },
    {
      id: 2,
      name: "EVgo Fast Charging Hub",
      location: "456 Oak Ave, New York, NY",
      status: "Active",
      connectors: 4,
      utilization: 72,
      revenue: "$1,890",
      lastMaintenance: "2024-01-08",
      qrScans: 98,
      avgRating: 4.5,
      totalSessions: 892,
      carbonOffset: 1923,
    },
    {
      id: 3,
      name: "ChargePoint Network Station",
      location: "789 Pine St, New York, NY",
      status: "Maintenance",
      connectors: 6,
      utilization: 0,
      revenue: "$0",
      lastMaintenance: "2024-01-15",
      qrScans: 0,
      avgRating: 4.2,
      totalSessions: 634,
      carbonOffset: 1456,
    },
  ]

  const recentBookings = [
    {
      id: 1,
      user: "John Doe",
      email: "john@example.com",
      station: "Tesla Supercharger - Downtown Plaza",
      time: "2024-01-15 14:30",
      duration: "45 min",
      amount: "$12.60",
      status: "Completed",
      vehicle: "Tesla Model 3",
      connector: "Tesla",
      carbonSaved: "2.3 kg",
    },
    {
      id: 2,
      user: "Sarah Chen",
      email: "sarah@example.com",
      station: "EVgo Fast Charging Hub",
      time: "2024-01-15 13:15",
      duration: "60 min",
      amount: "$19.20",
      status: "Completed",
      vehicle: "BMW i4",
      connector: "CCS",
      carbonSaved: "3.1 kg",
    },
    {
      id: 3,
      user: "Mike Rodriguez",
      email: "mike@example.com",
      station: "Tesla Supercharger - Downtown Plaza",
      time: "2024-01-15 12:00",
      duration: "30 min",
      amount: "$8.40",
      status: "In Progress",
      vehicle: "Tesla Model Y",
      connector: "Tesla",
      carbonSaved: "1.8 kg",
    },
  ]

  const analyticsData = {
    dailyBookings: [
      { date: "Jan 10", bookings: 45, revenue: 1250 },
      { date: "Jan 11", bookings: 52, revenue: 1420 },
      { date: "Jan 12", bookings: 48, revenue: 1380 },
      { date: "Jan 13", bookings: 61, revenue: 1650 },
      { date: "Jan 14", bookings: 55, revenue: 1520 },
      { date: "Jan 15", bookings: 67, revenue: 1890 },
      { date: "Jan 16", bookings: 59, revenue: 1670 },
    ],
    topStations: [
      { name: "Tesla Supercharger - Downtown", sessions: 1247, revenue: 2340 },
      { name: "EVgo Fast Charging Hub", sessions: 892, revenue: 1890 },
      { name: "ChargePoint Network", sessions: 634, revenue: 1250 },
    ],
    userGrowth: [
      { month: "Sep", users: 8500 },
      { month: "Oct", users: 9200 },
      { month: "Nov", users: 10100 },
      { month: "Dec", users: 11500 },
      { month: "Jan", users: 12800 },
    ],
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900">
      {/* Navigation */}
      <nav className="border-b border-slate-800/50 backdrop-blur-xl bg-slate-900/30 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="absolute inset-0 bg-red-500 rounded-lg blur-md opacity-30 animate-pulse" />
                <div className="relative bg-gradient-to-r from-red-500 to-red-600 p-2 rounded-lg">
                  <Shield className="h-6 w-6 text-white" />
                </div>
              </div>
              <div>
                <span className="text-xl font-bold bg-gradient-to-r from-red-400 to-red-500 bg-clip-text text-transparent">
                  Lumen Admin
                </span>
                <div className="text-xs text-slate-400 -mt-1">CONTROL PANEL</div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
                <SelectTrigger className="w-32 bg-slate-800 border-slate-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="24h">Last 24h</SelectItem>
                  <SelectItem value="7d">Last 7 days</SelectItem>
                  <SelectItem value="30d">Last 30 days</SelectItem>
                  <SelectItem value="90d">Last 90 days</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="ghost" className="text-slate-300 hover:text-yellow-400 relative">
                <Bell className="h-4 w-4" />
                <div className="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full" />
              </Button>
              
              <Button variant="ghost" className="text-slate-300 hover:text-green-400">
                <Settings className="h-4 w-4" />
              </Button>
              
              <Button variant="ghost" className="text-slate-300 hover:text-green-400">
                <User className="h-4 w-4 mr-2" />
                Admin
              </Button>
              
              <Button variant="ghost" className="text-slate-300 hover:text-red-400">
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Real-time Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-slate-800/50 border-slate-700 hover:border-green-400/30 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-2">
                    <p className="text-slate-400 text-sm font-medium">{stat.title}</p>
                    <p className="text-3xl font-bold text-white">{stat.value}</p>
                    <div className="flex items-center space-x-1">
                      {stat.trend === "up" ? (
                        <TrendingUp className="h-4 w-4 text-green-400" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-red-400" />
                      )}
                      <span className={`text-sm font-medium ${
                        stat.trend === "up" ? "text-green-400" : "text-red-400"
                      }`}>
                        {stat.change}
                      </span>
                    </div>
                  </div>
                  <div className="p-4 bg-slate-700/50 rounded-2xl">
                    {stat.icon}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-slate-800 border-slate-700">
            <TabsTrigger
              value="overview"
              className="data-[state=active]:bg-green-400 data-[state=active]:text-slate-900"
            >
              <BarChart3 className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger
              value="stations"
              className="data-[state=active]:bg-green-400 data-[state=active]:text-slate-900"
            >
              <Zap className="h-4 w-4 mr-2" />
              Stations
            </TabsTrigger>
            <TabsTrigger
              value="bookings"
              className="data-[state=active]:bg-green-400 data-[state=active]:text-slate-900"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Bookings
            </TabsTrigger>
            <TabsTrigger
              value="analytics"
              className="data-[state=active]:bg-green-400 data-[state=active]:text-slate-900"
            >
              <PieChart className="h-4 w-4 mr-2" />
              Analytics
            </TabsTrigger>
            <TabsTrigger
              value="users"
              className="data-[state=active]:bg-green-400 data-[state=active]:text-slate-900"
            >
              <Users className="h-4 w-4 mr-2" />
              Users
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Real-time Booking Heatmap */}
              <Card className="lg:col-span-2 bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Activity className="h-5 w-5 mr-2 text-green-400" />
                    Real-time Booking Heatmap
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80 bg-slate-700/50 rounded-lg flex items-center justify-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-green-400/10 to-blue-400/10" />
                    <div className="text-center space-y-4 z-10">
                      <Layers className="h-16 w-16 text-green-400 mx-auto animate-pulse" />
                      <div className="space-y-2">
                        <h3 className="text-white text-lg font-semibold">Interactive Heatmap</h3>
                        <p className="text-slate-400">Real-time booking density visualization</p>
                        <p className="text-slate-500 text-sm">Showing activity across all stations</p>
                      </div>
                    </div>

                    {/* Simulated heatmap points */}
                    <div className="absolute top-16 left-20">
                      <div className="w-8 h-8 bg-red-400/60 rounded-full animate-pulse" />
                    </div>
                    <div className="absolute top-24 right-32">
                      <div className="w-6 h-6 bg-yellow-400/60 rounded-full animate-pulse" />
                    </div>
                    <div className="absolute bottom-20 left-40">
                      <div className="w-10 h-10 bg-green-400/60 rounded-full animate-pulse" />
                    </div>
                    <div className="absolute bottom-32 right-24">
                      <div className="w-4 h-4 bg-blue-400/60 rounded-full animate-pulse" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Target className="h-5 w-5 mr-2 text-green-400" />
                    Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Dialog open={isAddStationOpen} onOpenChange={setIsAddStationOpen}>
                    <DialogTrigger asChild>
                      <Button className="w-full bg-green-400 hover:bg-green-500 text-slate-900 justify-start">
                        <Plus className="h-4 w-4 mr-2" />
                        Add New Station
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-3xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle className="flex items-center">
                          <Zap className="h-5 w-5 mr-2 text-green-400" />
                          Add New Charging Station
                        </DialogTitle>
                      </DialogHeader>
                      <div className="space-y-6">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Station Name</Label>
                            <Input placeholder="Enter station name" className="bg-slate-700 border-slate-600" />
                          </div>
                          <div>
                            <Label>Network Provider</Label>
                            <Select>
                              <SelectTrigger className="bg-slate-700 border-slate-600">
                                <SelectValue placeholder="Select provider" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="tesla">Tesla Supercharger</SelectItem>
                                <SelectItem value="evgo">EVgo</SelectItem>
                                <SelectItem value="chargepoint">ChargePoint</SelectItem>
                                <SelectItem value="electrify">Electrify America</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <div>
                          <Label>Address</Label>
                          <Textarea placeholder="Enter full address" className="bg-slate-700 border-slate-600" />
                        </div>

                        <div className="grid grid-cols-3 gap-4">
                          <div>
                            <Label>Number of Connectors</Label>
                            <Input type="number" placeholder="8" className="bg-slate-700 border-slate-600" />
                          </div>
                          <div>
                            <Label>Max Power (kWh)</Label>
                            <Input type="number" placeholder="150" className="bg-slate-700 border-slate-600" />
                          </div>
                          <div>
                            <Label>Price per kWh</Label>
                            <Input type="number" step="0.01" placeholder="0.28" className="bg-slate-700 border-slate-600" />
                          </div>
                        </div>

                        <div>
                          <Label>Connector Types</Label>
                          <div className="grid grid-cols-2 gap-4 mt-2">
                            {["Tesla", "CCS", "CHAdeMO", "J1772"].map((type) => (
                              <label key={type} className="flex items-center space-x-2">
                                <input type="checkbox" className="rounded" />
                                <span className="text-sm text-slate-300">{type}</span>
                              </label>
                            ))}
                          </div>
                        </div>

                        <div>
                          <Label>Amenities</Label>
                          <div className="grid grid-cols-3 gap-4 mt-2">
                            {["WiFi", "Restroom", "Food", "Shopping", "Parking", "24/7"].map((amenity) => (
                              <label key={amenity} className="flex items-center space-x-2">
                                <input type="checkbox" className="rounded" />
                                <span className="text-sm text-slate-300">{amenity}</span>
                              </label>
                            ))}
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Operating Hours</Label>
                            <Select>
                              <SelectTrigger className="bg-slate-700 border-slate-600">
                                <SelectValue placeholder="Select hours" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="24/7">24/7</SelectItem>
                                <SelectItem value="6am-10pm">6 AM - 10 PM</SelectItem>
                                <SelectItem value="8am-8pm">8 AM - 8 PM</SelectItem>
                                <SelectItem value="custom">Custom Hours</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="flex items-center space-x-2 pt-6">
                            <Switch id="qr-support" />
                            <Label htmlFor="qr-support">QR Code Support</Label>
                          </div>
                        </div>

                        <div className="flex space-x-4">
                          <Button variant="outline" className="flex-1 border-slate-600 text-slate-300 bg-transparent">
                            Cancel
                          </Button>
                          <Button className="flex-1 bg-green-400 hover:bg-green-500 text-slate-900">
                            Add Station
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Button variant="outline" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent justify-start">
                    <Download className="h-4 w-4 mr-2" />
                    Export Reports
                  </Button>

                  <Button variant="outline" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent justify-start">
                    <Settings className="h-4 w-4 mr-2" />
                    System Settings
                  </Button>

                  <Button variant="outline" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent justify-start">
                    <Bell className="h-4 w-4 mr-2" />
                    Notifications
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 mr-2 text-green-400" />
                    Recent Activity
                  </div>
                  <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                    View All
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentBookings.slice(0, 5).map((booking) => (
                    <div key={booking.id} className="flex items-center justify-between p-4 bg-slate-700/30 rounded-lg hover:bg-slate-700/50 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className={`w-3 h-3 rounded-full ${
                          booking.status === "Completed" ? "bg-green-400" : 
                          booking.status === "In Progress" ? "bg-blue-400" : "bg-yellow-400"
                        }`} />
                        <div>
                          <p className="text-white text-sm font-medium">{booking.user}</p>
                          <p className="text-slate-400 text-xs">{booking.station}</p>
                          <p className="text-slate-500 text-xs">{booking.time}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-green-400 text-sm font-medium">{booking.amount}</p>
                        <Badge
                          variant={
                            booking.status === "Completed" ? "default" : 
                            booking.status === "In Progress" ? "secondary" : "destructive"
                          }
                          className={
                            booking.status === "Completed" ? "bg-green-400/20 text-green-400" :
                            booking.status === "In Progress" ? "bg-blue-400/20 text-blue-400" : ""
                          }
                        >
                          {booking.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="stations" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Charging Stations Management</h2>
              <div className="flex space-x-2">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <Input
                    placeholder="Search stations..."
                    className="pl-10 w-64 bg-slate-800 border-slate-700 text-white"
                  />
                </div>
                <Button variant="outline" className="border-slate-600 text-slate-300 bg-transparent">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
              </div>
            </div>

            <div className="grid gap-6">
              {stations.map((station) => (
                <Card key={station.id} className="bg-slate-800/50 border-slate-700 hover:border-green-400/30 transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start">
                      <div className="space-y-4 flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="text-white text-xl font-semibold">{station.name}</h3>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="icon" className="text-slate-400 hover:text-green-400">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="text-slate-400 hover:text-blue-400">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="text-slate-400 hover:text-red-400">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2 text-slate-400">
                          <MapPin className="h-4 w-4" />
                          <span>{station.location}</span>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div className="space-y-1">
                            <div className="text-slate-400 text-sm">Status</div>
                            <Badge
                              variant={station.status === "Active" ? "default" : "destructive"}
                              className={station.status === "Active" ? "bg-green-400/20 text-green-400" : ""}
                            >
                              {station.status === "Active" ? (
                                <CheckCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <AlertTriangle className="h-3 w-3 mr-1" />
                              )}
                              {station.status}
                            </Badge>
                          </div>
                          
                          <div className="space-y-1">
                            <div className="text-slate-400 text-sm">Connectors</div>
                            <div className="text-white font-medium">{station.connectors}</div>
                          </div>
                          
                          <div className="space-y-1">
                            <div className="text-slate-400 text-sm">Utilization</div>
                            <div className="flex items-center space-x-2">
                              <div className="text-white font-medium">{station.utilization}%</div>
                              <div className="w-16 h-2 bg-slate-700 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full transition-all duration-300 ${
                                    station.utilization > 80 ? 'bg-red-400' :
                                    station.utilization > 60 ? 'bg-yellow-400' : 'bg-green-400'
                                  }`}
                                  style={{ width: `${station.utilization}%` }}
                                />
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-1">
                            <div className="text-slate-400 text-sm">Revenue</div>
                            <div className="text-green-400 font-bold">{station.revenue}</div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-slate-700">
                          <div className="space-y-1">
                            <div className="text-slate-400 text-sm">QR Scans</div>
                            <div className="text-white font-medium">{station.qrScans}</div>
                          </div>
                          
                          <div className="space-y-1">
                            <div className="text-slate-400 text-sm">Avg Rating</div>
                            <div className="flex items-center space-x-1">
                              <div className="text-white font-medium">{station.avgRating}</div>
                              <div className="flex">
                                {[...Array(5)].map((_, i) => (
                                  <div
                                    key={i}
                                    className={`w-3 h-3 ${
                                      i < Math.floor(station.avgRating) ? 'text-yellow-400' : 'text-slate-600'
                                    }`}
                                  >
                                    ★
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-1">
                            <div className="text-slate-400 text-sm">Total Sessions</div>
                            <div className="text-white font-medium">{station.totalSessions.toLocaleString()}</div>
                          </div>
                          
                          <div className="space-y-1">
                            <div className="text-slate-400 text-sm">CO₂ Saved</div>
                            <div className="text-green-400 font-medium">{station.carbonOffset} kg</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="bookings" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Booking Management</h2>
              <div className="flex space-x-2">
                <Select>
                  <SelectTrigger className="w-40 bg-slate-800 border-slate-700 text-white">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Bookings</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" className="border-slate-600 text-slate-300 bg-transparent">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="border-b border-slate-700">
                      <tr className="text-left">
                        <th className="p-4 text-slate-300 font-medium">User</th>
                        <th className="p-4 text-slate-300 font-medium">Station</th>
                        <th className="p-4 text-slate-300 font-medium">Vehicle</th>
                        <th className="p-4 text-slate-300 font\
