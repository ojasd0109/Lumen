"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Zap,
  MapPin,
  Clock,
  Leaf,
  Star,
  ChevronRight,
  Play,
  Smartphone,
  TrendingUp,
  Users,
  Building,
  ArrowRight,
  CheckCircle,
  Globe,
  Shield,
  Sparkles,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function LandingPage() {
  const [carbonSaved, setCarbonSaved] = useState(0)
  const [activeTestimonial, setActiveTestimonial] = useState(0)

  // Animated counter for carbon savings
  useEffect(() => {
    const interval = setInterval(() => {
      setCarbonSaved((prev) => (prev < 125847 ? prev + 1247 : 125847))
    }, 100)
    return () => clearInterval(interval)
  }, [])

  // Auto-rotate testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  const features = [
    {
      icon: <Leaf className="h-12 w-12 text-green-400" />,
      title: "Eco-Friendly Impact",
      description: "Track your carbon footprint reduction and contribute to a cleaner planet with every charge",
      stats: "125K+ kg CO₂ saved",
    },
    {
      icon: <Clock className="h-12 w-12 text-blue-400" />,
      title: "Real-time Station Data",
      description: "Live availability, pricing, and status updates from thousands of charging stations worldwide",
      stats: "99.9% uptime",
    },
    {
      icon: <Smartphone className="h-12 w-12 text-purple-400" />,
      title: "Smart Booking System",
      description: "Reserve charging slots, get QR codes for seamless check-in, and receive intelligent reminders",
      stats: "30s avg booking",
    },
  ]

  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Tesla Model Y Owner",
      company: "Tech Startup Founder",
      content:
        "Lumen has revolutionized my daily commute. The predictive booking and real-time updates mean I never worry about finding a charger.",
      rating: 5,
      avatar: "/placeholder.svg?height=80&width=80",
      verified: true,
    },
    {
      name: "Marcus Rodriguez",
      role: "Fleet Manager",
      company: "GreenLogistics Corp",
      content:
        "Managing our 50+ EV fleet became effortless with Lumen's business dashboard. The analytics help us optimize routes and reduce costs.",
      rating: 5,
      avatar: "/placeholder.svg?height=80&width=80",
      verified: true,
    },
    {
      name: "Emma Thompson",
      role: "BMW i4 Driver",
      company: "Environmental Consultant",
      content:
        "The carbon impact tracking is incredible! Seeing my environmental contribution motivates me to drive electric every day.",
      rating: 5,
      avatar: "/placeholder.svg?height=80&width=80",
      verified: true,
    },
  ]

  const stats = [
    { label: "Active Stations", value: "50K+", icon: <Zap className="h-6 w-6" /> },
    { label: "Happy Drivers", value: "2M+", icon: <Users className="h-6 w-6" /> },
    { label: "Cities Covered", value: "500+", icon: <Globe className="h-6 w-6" /> },
    { label: "CO₂ Saved", value: "125K kg", icon: <Leaf className="h-6 w-6" /> },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-green-400/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-400/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-400/5 rounded-full blur-3xl animate-pulse" />
      </div>

      {/* Navigation */}
      <nav className="relative z-50 border-b border-slate-800/50 backdrop-blur-xl bg-slate-900/30 sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="absolute inset-0 bg-green-400 rounded-lg blur-md opacity-30 animate-pulse" />
                <div className="relative bg-gradient-to-r from-green-400 to-emerald-400 p-2 rounded-lg">
                  <Zap className="h-8 w-8 text-slate-900" />
                </div>
              </div>
              <div>
                <span className="text-3xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                  Lumen
                </span>
                <div className="text-xs text-slate-400 -mt-1">EV CHARGING</div>
              </div>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <Link
                href="#features"
                className="text-slate-300 hover:text-green-400 transition-all duration-300 hover:scale-105"
              >
                Features
              </Link>
              <Link
                href="#testimonials"
                className="text-slate-300 hover:text-green-400 transition-all duration-300 hover:scale-105"
              >
                Reviews
              </Link>
              <Link
                href="#business"
                className="text-slate-300 hover:text-green-400 transition-all duration-300 hover:scale-105"
              >
                For Business
              </Link>
              <Link href="/auth/login">
                <Button
                  variant="outline"
                  className="border-green-400/30 text-green-400 hover:bg-green-400/10 hover:border-green-400 bg-transparent backdrop-blur-sm transition-all duration-300"
                >
                  Sign In
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button className="bg-gradient-to-r from-green-400 to-emerald-500 hover:from-green-500 hover:to-emerald-600 text-slate-900 font-semibold shadow-lg shadow-green-400/25 transition-all duration-300 hover:scale-105">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-10">
              <div className="space-y-6">
                <Badge className="bg-gradient-to-r from-green-400/20 to-emerald-400/20 text-green-400 border-green-400/30 backdrop-blur-sm">
                  <Sparkles className="h-4 w-4 mr-2" />
                  Powered by AI & Real-time Data
                </Badge>

                <h1 className="text-5xl lg:text-7xl font-bold leading-tight">
                  <span className="text-white">Power Your</span>
                  <br />
                  <span className="text-white">Drive with </span>
                  <span className="bg-gradient-to-r from-green-400 via-emerald-400 to-blue-400 bg-clip-text text-transparent animate-pulse">
                    Lumen
                  </span>
                </h1>

                <p className="text-xl lg:text-2xl text-slate-300 leading-relaxed max-w-2xl">
                  Discover, book, and charge at thousands of EV stations worldwide. Real-time availability, smart
                  booking, and carbon impact tracking.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-6">
                <Link href="/dashboard">
                  <Button
                    size="lg"
                    className="bg-gradient-to-r from-green-400 to-emerald-500 hover:from-green-500 hover:to-emerald-600 text-slate-900 font-bold text-lg px-8 py-4 shadow-2xl shadow-green-400/25 group transition-all duration-300 hover:scale-105"
                  >
                    <MapPin className="h-6 w-6 mr-3" />
                    Find Charging Stations
                    <ChevronRight className="h-6 w-6 ml-3 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>

                <Button
                  size="lg"
                  variant="outline"
                  className="border-slate-600/50 text-slate-300 hover:bg-slate-800/50 backdrop-blur-sm group text-lg px-8 py-4 transition-all duration-300 hover:scale-105 bg-transparent"
                >
                  <Play className="h-6 w-6 mr-3" />
                  Watch Demo
                </Button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 pt-8">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center space-y-2">
                    <div className="flex items-center justify-center text-green-400 mb-2">{stat.icon}</div>
                    <div className="text-2xl font-bold text-white">{stat.value}</div>
                    <div className="text-sm text-slate-400">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Hero Animation/Graphic */}
            <div className="relative">
              <div className="relative z-10">
                <div className="relative bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-xl rounded-3xl p-8 border border-slate-700/50">
                  <div className="aspect-square bg-gradient-to-br from-green-400/20 to-blue-400/20 rounded-2xl flex items-center justify-center relative overflow-hidden">
                    {/* Animated EV Graphic Placeholder */}
                    <div className="relative">
                      <div className="w-32 h-32 bg-gradient-to-r from-green-400 to-emerald-400 rounded-2xl flex items-center justify-center animate-pulse">
                        <Zap className="h-16 w-16 text-slate-900" />
                      </div>
                      <div className="absolute -top-4 -right-4 w-8 h-8 bg-green-400 rounded-full animate-ping" />
                      <div
                        className="absolute -bottom-4 -left-4 w-6 h-6 bg-blue-400 rounded-full animate-ping"
                        style={{ animationDelay: "1s" }}
                      />
                    </div>

                    {/* Floating elements */}
                    <div className="absolute top-8 right-8 bg-slate-800/80 backdrop-blur-sm rounded-lg p-3 animate-bounce">
                      <div className="text-green-400 text-sm font-medium">⚡ 150kW</div>
                    </div>
                    <div
                      className="absolute bottom-8 left-8 bg-slate-800/80 backdrop-blur-sm rounded-lg p-3 animate-bounce"
                      style={{ animationDelay: "0.5s" }}
                    >
                      <div className="text-blue-400 text-sm font-medium">🔋 Available</div>
                    </div>
                  </div>

                  {/* Carbon Counter */}
                  <div className="mt-6 text-center">
                    <div className="text-3xl font-bold text-green-400">{carbonSaved.toLocaleString()}</div>
                    <div className="text-slate-400 text-sm">kg CO₂ saved globally</div>
                  </div>
                </div>
              </div>

              {/* Background glow */}
              <div className="absolute inset-0 bg-gradient-to-r from-green-400/10 to-blue-400/10 rounded-3xl blur-3xl" />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6 mb-20">
            <Badge className="bg-gradient-to-r from-blue-400/20 to-purple-400/20 text-blue-400 border-blue-400/30">
              <Sparkles className="h-4 w-4 mr-2" />
              Advanced Features
            </Badge>
            <h2 className="text-4xl lg:text-5xl font-bold text-white">
              Why Choose <span className="text-green-400">Lumen</span>?
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Experience the future of EV charging with our intelligent platform powered by real-time data and AI
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-slate-700/50 hover:border-green-400/30 transition-all duration-500 group backdrop-blur-xl hover:scale-105"
              >
                <CardContent className="p-8 space-y-6">
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-green-400/20 to-blue-400/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    <div className="relative w-20 h-20 bg-slate-800/50 rounded-2xl flex items-center justify-center group-hover:bg-slate-700/50 transition-colors duration-300">
                      {feature.icon}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-2xl font-bold text-white group-hover:text-green-400 transition-colors duration-300">
                      {feature.title}
                    </h3>
                    <p className="text-slate-300 leading-relaxed">{feature.description}</p>
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-green-400 border-green-400/30">
                        {feature.stats}
                      </Badge>
                      <ArrowRight className="h-5 w-5 text-slate-400 group-hover:text-green-400 group-hover:translate-x-1 transition-all duration-300" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-24 bg-gradient-to-r from-slate-900/50 to-indigo-900/30 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6 mb-16">
            <Badge className="bg-gradient-to-r from-purple-400/20 to-pink-400/20 text-purple-400 border-purple-400/30">
              <Users className="h-4 w-4 mr-2" />
              Customer Stories
            </Badge>
            <h2 className="text-4xl lg:text-5xl font-bold text-white">
              Loved by <span className="text-green-400">EV Drivers</span>
            </h2>
            <p className="text-xl text-slate-300">Join millions of satisfied customers worldwide</p>
          </div>

          <div className="relative max-w-4xl mx-auto">
            <Card className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-slate-700/50 backdrop-blur-xl">
              <CardContent className="p-12">
                <div className="text-center space-y-8">
                  <div className="flex justify-center space-x-1 mb-6">
                    {[...Array(testimonials[activeTestimonial].rating)].map((_, i) => (
                      <Star key={i} className="h-6 w-6 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>

                  <blockquote className="text-2xl lg:text-3xl text-slate-200 italic leading-relaxed">
                    "{testimonials[activeTestimonial].content}"
                  </blockquote>

                  <div className="flex items-center justify-center space-x-4">
                    <div className="relative">
                      <Image
                        src={testimonials[activeTestimonial].avatar || "/placeholder.svg"}
                        alt={testimonials[activeTestimonial].name}
                        width={80}
                        height={80}
                        className="rounded-full border-2 border-green-400/30"
                      />
                      {testimonials[activeTestimonial].verified && (
                        <div className="absolute -bottom-1 -right-1 bg-green-400 rounded-full p-1">
                          <CheckCircle className="h-4 w-4 text-slate-900" />
                        </div>
                      )}
                    </div>
                    <div className="text-left">
                      <div className="text-xl font-bold text-white">{testimonials[activeTestimonial].name}</div>
                      <div className="text-green-400 font-medium">{testimonials[activeTestimonial].role}</div>
                      <div className="text-slate-400 text-sm">{testimonials[activeTestimonial].company}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Testimonial indicators */}
            <div className="flex justify-center space-x-3 mt-8">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === activeTestimonial ? "bg-green-400 scale-125" : "bg-slate-600 hover:bg-slate-500"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Business CTA Section */}
      <section id="business" className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="bg-gradient-to-r from-green-400/10 to-blue-400/10 border-green-400/20 backdrop-blur-xl">
            <CardContent className="p-12 text-center space-y-8">
              <div className="space-y-4">
                <Badge className="bg-gradient-to-r from-green-400/20 to-emerald-400/20 text-green-400 border-green-400/30">
                  <Building className="h-4 w-4 mr-2" />
                  For Businesses
                </Badge>
                <h2 className="text-4xl lg:text-5xl font-bold text-white">
                  List Your <span className="text-green-400">Charging Station</span>
                </h2>
                <p className="text-xl text-slate-300 max-w-3xl mx-auto">
                  Join thousands of businesses earning revenue by listing their charging stations on Lumen. Get access
                  to our business dashboard, analytics, and customer management tools.
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-8 my-12">
                <div className="space-y-3">
                  <div className="w-16 h-16 bg-green-400/20 rounded-2xl flex items-center justify-center mx-auto">
                    <TrendingUp className="h-8 w-8 text-green-400" />
                  </div>
                  <h3 className="text-xl font-bold text-white">Increase Revenue</h3>
                  <p className="text-slate-400">Monetize your charging infrastructure with dynamic pricing</p>
                </div>
                <div className="space-y-3">
                  <div className="w-16 h-16 bg-blue-400/20 rounded-2xl flex items-center justify-center mx-auto">
                    <Users className="h-8 w-8 text-blue-400" />
                  </div>
                  <h3 className="text-xl font-bold text-white">Reach More Customers</h3>
                  <p className="text-slate-400">Connect with millions of EV drivers actively seeking charging</p>
                </div>
                <div className="space-y-3">
                  <div className="w-16 h-16 bg-purple-400/20 rounded-2xl flex items-center justify-center mx-auto">
                    <Shield className="h-8 w-8 text-purple-400" />
                  </div>
                  <h3 className="text-xl font-bold text-white">Enterprise Support</h3>
                  <p className="text-slate-400">24/7 support and dedicated account management</p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-green-400 to-emerald-500 hover:from-green-500 hover:to-emerald-600 text-slate-900 font-bold text-lg px-8 py-4 transition-all duration-300 hover:scale-105"
                >
                  <Building className="h-6 w-6 mr-3" />
                  List Your Station
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-slate-600/50 text-slate-300 hover:bg-slate-800/50 backdrop-blur-sm text-lg px-8 py-4 transition-all duration-300 hover:scale-105 bg-transparent"
                >
                  Learn More
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-gradient-to-r from-green-400/10 to-blue-400/10">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="space-y-6">
            <h2 className="text-4xl lg:text-5xl font-bold text-white">
              Ready to Start Your <span className="text-green-400">Electric Journey</span>?
            </h2>
            <p className="text-xl text-slate-300">
              Join the electric revolution and discover charging stations near you
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Link href="/auth/signup">
              <Button
                size="lg"
                className="bg-gradient-to-r from-green-400 to-emerald-500 hover:from-green-500 hover:to-emerald-600 text-slate-900 font-bold text-lg px-10 py-4 shadow-2xl shadow-green-400/25 transition-all duration-300 hover:scale-105"
              >
                Get Started Free
                <ChevronRight className="h-6 w-6 ml-3" />
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button
                size="lg"
                variant="outline"
                className="border-green-400/30 text-green-400 hover:bg-green-400/10 backdrop-blur-sm text-lg px-10 py-4 transition-all duration-300 hover:scale-105 bg-transparent"
              >
                Explore Map
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950/80 backdrop-blur-xl border-t border-slate-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid md:grid-cols-5 gap-8">
            <div className="md:col-span-2 space-y-6">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <div className="absolute inset-0 bg-green-400 rounded-lg blur-md opacity-30" />
                  <div className="relative bg-gradient-to-r from-green-400 to-emerald-400 p-2 rounded-lg">
                    <Zap className="h-6 w-6 text-slate-900" />
                  </div>
                </div>
                <div>
                  <span className="text-2xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                    Lumen
                  </span>
                  <div className="text-xs text-slate-400 -mt-1">EV CHARGING</div>
                </div>
              </div>
              <p className="text-slate-400 max-w-md">
                Powering the future of electric mobility with intelligent charging solutions and real-time data.
              </p>
              <div className="flex space-x-4">
                {["twitter", "linkedin", "instagram", "youtube"].map((social) => (
                  <Link
                    key={social}
                    href={`#${social}`}
                    className="w-10 h-10 bg-slate-800/50 rounded-lg flex items-center justify-center text-slate-400 hover:text-green-400 hover:bg-slate-700/50 transition-all duration-300"
                  >
                    <div className="w-5 h-5 bg-current rounded" />
                  </Link>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-white font-bold text-lg">Product</h3>
              <div className="space-y-3">
                {["Features", "Pricing", "API", "Mobile App"].map((item) => (
                  <Link
                    key={item}
                    href="#"
                    className="block text-slate-400 hover:text-green-400 transition-colors duration-300"
                  >
                    {item}
                  </Link>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-white font-bold text-lg">Company</h3>
              <div className="space-y-3">
                {["About", "Careers", "Press", "Contact"].map((item) => (
                  <Link
                    key={item}
                    href="#"
                    className="block text-slate-400 hover:text-green-400 transition-colors duration-300"
                  >
                    {item}
                  </Link>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-white font-bold text-lg">Legal</h3>
              <div className="space-y-3">
                {["Privacy Policy", "Terms of Service", "Cookie Policy", "Security"].map((item) => (
                  <Link
                    key={item}
                    href="#"
                    className="block text-slate-400 hover:text-green-400 transition-colors duration-300"
                  >
                    {item}
                  </Link>
                ))}
              </div>
            </div>
          </div>

          <div className="border-t border-slate-800/50 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-slate-400 text-sm">&copy; 2024 Lumen. All rights reserved.</p>
            <div className="flex items-center space-x-6 mt-4 md:mt-0">
              <Badge variant="outline" className="text-green-400 border-green-400/30">
                <Leaf className="h-3 w-3 mr-1" />
                Carbon Neutral
              </Badge>
              <Badge variant="outline" className="text-blue-400 border-blue-400/30">
                <Shield className="h-3 w-3 mr-1" />
                SOC 2 Compliant
              </Badge>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
